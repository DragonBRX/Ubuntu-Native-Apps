# ULX - Início Rápido

## Instalar e Executar em Um Comando

### **Opção 1: Clonar e Executar (Recomendado)**

**Copie e cole este comando no seu terminal:**

```bash
git clone https://github.com/DragonSCPOFICIAL/ULX.git && cd ULX && chmod +x system-monitor && ./system-monitor
```

**Pronto! O Monitor de Sistema está rodando!** 🚀

---

### **Opção 2: Se Já Tem a Pasta ULX Clonada**

Se você já clonou o repositório antes e recebe erro "destination path 'ULX' already exists":

```bash
cd ULX && git pull origin main && chmod +x system-monitor && ./system-monitor
```

Isso atualiza a pasta existente com a versão mais recente.

---

### **Opção 3: Clonar em Pasta Diferente**

Se quer manter a pasta antiga e clonar em uma nova:

```bash
git clone https://github.com/DragonSCPOFICIAL/ULX.git ULX-novo && cd ULX-novo && chmod +x system-monitor && ./system-monitor
```

---

## O Que Cada Comando Faz

### **Opção 1:**

```bash
git clone https://github.com/DragonSCPOFICIAL/ULX.git
# ↓ Baixa o repositório ULX

&& cd ULX
# ↓ Entra na pasta ULX

&& chmod +x system-monitor
# ↓ Dá permissão de execução ao programa compilado

&& ./system-monitor
# ↓ Executa o Monitor de Sistema
```

### **Opção 2:**

```bash
cd ULX
# ↓ Entra na pasta ULX existente

&& git pull origin main
# ↓ Atualiza o repositório com a versão mais recente

&& chmod +x system-monitor
# ↓ Dá permissão de execução

&& ./system-monitor
# ↓ Executa o Monitor de Sistema
```

### **Opção 3:**

```bash
git clone https://github.com/DragonSCPOFICIAL/ULX.git ULX-novo
# ↓ Clona em uma pasta nova chamada ULX-novo

&& cd ULX-novo
# ↓ Entra na pasta nova

&& chmod +x system-monitor
# ↓ Dá permissão de execução

&& ./system-monitor
# ↓ Executa o Monitor de Sistema
```

---

## Resultado

Você verá o Monitor de Sistema mostrando:

```
╔════════════════════════════════════════════════════════════════╗
║          MONITOR DE SISTEMA - ULX                             ║
║          Informações Completas do Hardware                    ║
╚════════════════════════════════════════════════════════════════╝

┌─ CPU ─────────────────────────────────────────────────────────┐
  processor: 0
  model name: Intel(R) Xeon(R) Processor @ 2.10GHz
  cpu MHz: 2100.000
│

┌─ MEMÓRIA ──────────────────────────────────────────────────────┐
  Total: 3.8Gi
  Usada: 1.7Gi
  Disponível: 1.9Gi
│

┌─ ARMAZENAMENTO ────────────────────────────────────────────────┐
  Raiz: /dev/root 42G 11G 25%
│

┌─ UPTIME ───────────────────────────────────────────────────────┐
   2 days, 10:41,  2 users,  load average: 0.01, 0.04, 0.03
│

┌─ TOP 5 PROCESSOS ──────────────────────────────────────────────┐
  ubuntu     1.1  11.8 node
  ubuntu     1.1   0.3 /usr/lib/git-core/git
│

┌─ REDE ─────────────────────────────────────────────────────────┐
  lo:
  eth0:
│

└────────────────────────────────────────────────────────────────┘

Pressione Ctrl+C para sair
```

---

## Sair do Monitor

Pressione `Ctrl+C` para sair do programa.

---

## Executar Novamente

Se você já tem o repositório clonado, pode executar direto:

```bash
cd ULX && ./system-monitor
```

Ou se clonou em pasta diferente:

```bash
cd ULX-novo && ./system-monitor
```

---

## Instalar Globalmente (Opcional)

Para usar o Monitor em qualquer lugar do sistema:

```bash
sudo cp ULX/examples/system_monitor /usr/local/bin/ulx-monitor
ulx-monitor
```

---

## Próximos Passos

1. **Explore o repositório:**
   ```bash
   cd ULX
   ls -la
   ```

2. **Leia a documentação:**
   - `README.md` - Visão geral
   - `ULX_SYNTAX.md` - Sintaxe da linguagem
   - `ARCHITECTURE.md` - Arquitetura

3. **Crie seu próprio programa:**
   ```bash
   cat > meu_programa.ulx << 'EOF'
   escreva("Olá, mundo!")
   EOF
   ```

4. **Compile:**
   ```bash
   python3 src/compiler/clx_compiler_intelligent.py meu_programa.ulx
   ```

5. **Execute:**
   ```bash
   ./meu_programa
   ```

---

## Requisitos

- Linux (qualquer distribuição)
- Git
- Bash/Shell

**Nada mais é necessário!** O binário já está compilado e pronto para usar.

---

## Suporte

- **GitHub:** https://github.com/DragonSCPOFICIAL/ULX
- **Issues:** Reporte bugs e sugestões
- **Discussions:** Discuta ideias

---

**Bem-vindo ao ULX!** 🚀
